class SchoolClass {
  final int dayId;
  final String day;
  final String teacher;
  //diventa la classe subject
  final String subject;
  final String time;
  final String room;

  SchoolClass(this.dayId,this.day, this.teacher, this.subject, this.time, this.room);
}

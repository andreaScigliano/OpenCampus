class Sobject {
  int idSobject;
  String name;
  List<String> document;
  

}
import 'package:flutter/material.dart';

class PersonalDoc extends StatefulWidget {
  PersonalDoc({Key key}) : super(key: key);
  @override
  _PersonalDocState createState() => _PersonalDocState();
}

class _PersonalDocState extends State<PersonalDoc> {
  @override
  Widget build(BuildContext context) {

  }
}
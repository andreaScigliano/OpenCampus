import 'package:flutter/material.dart';

class Paramiter extends StatefulWidget {
  Paramiter({Key key}) : super(key: key);
  @override
  _ParamiterState createState() => _ParamiterState();
}

class _ParamiterState extends State<Paramiter> {
  @override
  Widget build(BuildContext context) {

  }
}